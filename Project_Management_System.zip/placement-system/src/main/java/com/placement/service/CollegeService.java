package com.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.entity.College;
import com.placement.repository.CollegeRepository;

@Service
public class CollegeService {

    @Autowired
    private CollegeRepository repository;

    public College addCollege(College college){
        return repository.save(college);
    }

    public List<College> getAllColleges(){
        return repository.findAll();
    }

}