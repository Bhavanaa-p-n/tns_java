package com.placement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.placement.entity.College;
import com.placement.service.CollegeService;

@RestController
@RequestMapping("/college")
public class CollegeController {

    @Autowired
    private CollegeService service;

    @PostMapping("/add")
    public College addCollege(@RequestBody College college){
        return service.addCollege(college);
    }

    @GetMapping("/all")
    public List<College> getColleges(){
        return service.getAllColleges();
    }
}