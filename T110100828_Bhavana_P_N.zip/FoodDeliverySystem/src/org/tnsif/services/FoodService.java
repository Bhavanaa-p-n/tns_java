package org.tnsif.services;

import java.util.*;
import org.tnsif.entities.*;



public class FoodService {
	


	    private List<Restaurant> restaurants = new ArrayList<>();

	    public void addRestaurant(Restaurant r) {
	        restaurants.add(r);
	    }

	    public List<Restaurant> getRestaurants() {
	        return restaurants;
	    }

	    public Restaurant getRestaurant(int id) {
	        for(Restaurant r:restaurants)
	            if(r.getId()==id)
	                return r;
	        return null;
	    }
	}
	

