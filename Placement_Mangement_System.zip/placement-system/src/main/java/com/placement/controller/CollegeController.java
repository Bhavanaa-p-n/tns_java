
package com.placement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.placement.entity.College;
import com.placement.service.CollegeService;

@RestController
@RequestMapping("/college")
public class CollegeController {

    @Autowired
    private CollegeService service;

    // CREATE
    @PostMapping("/add")
    public College addCollege(@RequestBody College college) {
        return service.addCollege(college);
    }

    // READ ALL
    @GetMapping("/all")
    public List<College> getAllColleges() {
        return service.getAllColleges();
    }

    // UPDATE
    @PutMapping("/update/{id}")
    public College updateCollege(@PathVariable int id, @RequestBody College college) {
        college.setId(id);
        return service.addCollege(college);
    }

    // DELETE
    @DeleteMapping("/delete/{id}")
    public String deleteCollege(@PathVariable int id) {
        service.deleteCollege(id);
        return "College deleted successfully";
    }
}

