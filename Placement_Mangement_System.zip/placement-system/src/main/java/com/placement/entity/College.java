package com.placement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class College {

    @Id
    private int id;
    private String collegeName;
    private String location;

    public College(){}

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id=id;
    }

    public String getCollegeName(){
        return collegeName;
    }

    public void setCollegeName(String collegeName){
        this.collegeName=collegeName;
    }

    public String getLocation(){
        return location;
    }

    public void setLocation(String location){
        this.location=location;
    }
}