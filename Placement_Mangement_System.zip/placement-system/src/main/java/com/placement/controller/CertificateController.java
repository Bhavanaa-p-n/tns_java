package com.placement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.placement.entity.Certificate;
import com.placement.service.CertificateService;

@RestController
@RequestMapping("/certificate")
public class CertificateController {

    @Autowired
    private CertificateService service;

    @PostMapping("/add")
    public Certificate addCertificate(@RequestBody Certificate certificate){
        return service.addCertificate(certificate);
    }

    @GetMapping("/all")
    public List<Certificate> getCertificates(){
        return service.getCertificates();
    }
}