package com.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.entity.Certificate;
import com.placement.repository.CertificateRepository;

@Service
public class CertificateService {

    @Autowired
    private CertificateRepository repository;

    public Certificate addCertificate(Certificate certificate){
        return repository.save(certificate);
    }

    public List<Certificate> getCertificates(){
        return repository.findAll();
    }

}