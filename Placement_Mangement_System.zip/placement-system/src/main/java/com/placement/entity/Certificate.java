package com.placement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Certificate {

    @Id
    private int id;
    private String course;
    private String organization;

    public Certificate(){}

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id=id;
    }

    public String getCourse(){
        return course;
    }

    public void setCourse(String course){
        this.course=course;
    }

    public String getOrganization(){
        return organization;
    }

    public void setOrganization(String organization){
        this.organization=organization;
    }
}