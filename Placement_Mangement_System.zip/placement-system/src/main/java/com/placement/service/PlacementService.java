package com.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.entity.Placement;
import com.placement.repository.PlacementRepository;

@Service
public class PlacementService {

    @Autowired
    private PlacementRepository repository;

    public Placement addPlacement(Placement placement){
        return repository.save(placement);
    }

    public List<Placement> getPlacements(){
        return repository.findAll();
    }

}