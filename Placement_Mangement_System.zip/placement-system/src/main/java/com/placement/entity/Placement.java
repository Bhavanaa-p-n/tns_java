package com.placement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Placement {

    @Id
    private int id;
    private String company;
    private String role;

    public Placement(){}

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id=id;
    }

    public String getCompany(){
        return company;
    }

    public void setCompany(String company){
        this.company=company;
    }

    public String getRole(){
        return role;
    }

    public void setRole(String role){
        this.role=role;
    }
}