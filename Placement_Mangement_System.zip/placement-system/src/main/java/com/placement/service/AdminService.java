package com.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.entity.Admin;
import com.placement.repository.AdminRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository repository;

    public Admin addAdmin(Admin admin){
        return repository.save(admin);
    }

    public List<Admin> getAdmins(){
        return repository.findAll();
    }

}