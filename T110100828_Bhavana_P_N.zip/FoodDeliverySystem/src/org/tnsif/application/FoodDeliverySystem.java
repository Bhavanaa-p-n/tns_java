package org.tnsif.application;

import java.util.Scanner;
import org.tnsif.entities.*;
import org.tnsif.services.*;

public class FoodDeliverySystem {
	
	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        CustomerService customerService = new CustomerService();
	        FoodService foodService = new FoodService();
	        OrderService orderService = new OrderService();

	        int mainChoice;

	        do {

	            System.out.println("\n==== Food Delivery System ====");
	            System.out.println("1. Admin Menu");
	            System.out.println("2. Customer Menu");
	            System.out.println("3. Exit");
	            System.out.print("Choose option: ");

	            mainChoice = sc.nextInt();

	            switch (mainChoice) {

	                case 1:

	                    int adminChoice;

	                    do {

	                        System.out.println("\n--- Admin Menu ---");
	                        System.out.println("1. Add Restaurant");
	                        System.out.println("2. Add Food Item to Restaurant");
	                        System.out.println("3. View Restaurants and Menus");
	                        System.out.println("4. View Orders");
	                        System.out.println("5. Add Delivery Person");
	                        System.out.println("6. Assign Delivery Person to Order");
	                        System.out.println("7. Exit");

	                        adminChoice = sc.nextInt();

	                        switch (adminChoice) {

	                            case 1:

	                                System.out.print("Enter Restaurant ID: ");
	                                int rid = sc.nextInt();
	                                sc.nextLine();

	                                System.out.print("Enter Restaurant Name: ");
	                                String rname = sc.nextLine();

	                                Restaurant r = new Restaurant(rid, rname);
	                                foodService.addRestaurant(r);

	                                System.out.println("Restaurant added successfully!");
	                                break;

	                            case 2:

	                                System.out.print("Enter Restaurant ID: ");
	                                int restId = sc.nextInt();

	                                Restaurant rest = foodService.getRestaurant(restId);

	                                if (rest != null) {

	                                    System.out.print("Enter Food Item ID: ");
	                                    int fid = sc.nextInt();
	                                    sc.nextLine();

	                                    System.out.print("Enter Food Name: ");
	                                    String fname = sc.nextLine();

	                                    System.out.print("Enter Price: ");
	                                    double price = sc.nextDouble();

	                                    FoodItem item = new FoodItem(fid, fname, price);

	                                    rest.addFoodItem(item);

	                                    System.out.println("Food item added successfully!");

	                                } else {

	                                    System.out.println("Restaurant not found!");

	                                }

	                                break;

	                            case 3:

	                                System.out.println("\nRestaurants and Menus:");

	                                for (Restaurant restaurant : foodService.getRestaurants()) {

	                                    System.out.println("Restaurant ID: " + restaurant.getId()
	                                            + ", Name: " + restaurant.getName());

	                                    for (FoodItem f : restaurant.getMenu()) {

	                                        System.out.println("  Food ID: " + f.getId()
	                                                + " Name: " + f.getName()
	                                                + " Price: Rs." + f.getPrice());
	                                    }
	                                }

	                                break;

	                            case 4:

	                                System.out.println("\nOrders:");

	                                for (Order o : orderService.getOrders()) {

	                                    System.out.println(o);
	                                }

	                                break;

	                            case 5:

	                                System.out.print("Enter Delivery Person ID: ");
	                                int dpid = sc.nextInt();
	                                sc.nextLine();

	                                System.out.print("Enter Name: ");
	                                String dpname = sc.nextLine();

	                                System.out.print("Enter Contact No: ");
	                                long contact = sc.nextLong();

	                                DeliveryPerson dp =
	                                        new DeliveryPerson(dpid, dpname, contact);

	                                orderService.addDeliveryPerson(dp);

	                                System.out.println("Delivery person added successfully!");

	                                break;

	                            case 6:

	                                System.out.print("Enter Order ID: ");
	                                int oid = sc.nextInt();

	                                System.out.print("Enter Delivery Person ID: ");
	                                int did = sc.nextInt();

	                                orderService.assignDeliveryPerson(oid, did);

	                                System.out.println("Delivery person assigned successfully!");

	                                break;

	                        }

	                    } while (adminChoice != 7);

	                    break;

	                case 2:

	                    int customerChoice;

	                    do {

	                        System.out.println("\n--- Customer Menu ---");
	                        System.out.println("1. Add Customer");
	                        System.out.println("2. View Food Items");
	                        System.out.println("3. Add Food to Cart");
	                        System.out.println("4. View Cart");
	                        System.out.println("5. Place Order");
	                        System.out.println("6. View Orders");
	                        System.out.println("7. Exit");

	                        customerChoice = sc.nextInt();

	                        switch (customerChoice) {

	                            case 1:

	                                System.out.print("Enter User ID: ");
	                                int uid = sc.nextInt();
	                                sc.nextLine();

	                                System.out.print("Enter Username: ");
	                                String uname = sc.nextLine();

	                                System.out.print("Enter Contact No: ");
	                                long phone = sc.nextLong();

	                                Customer c = new Customer(uid, uname, phone);

	                                customerService.addCustomer(c);

	                                System.out.println("Customer created successfully!");

	                                break;

	                            case 2:

	                                for (Restaurant restaurant : foodService.getRestaurants()) {

	                                    System.out.println("\nRestaurant ID: " + restaurant.getId()
	                                            + ", Name: " + restaurant.getName());

	                                    for (FoodItem f : restaurant.getMenu()) {

	                                        System.out.println("Food ID: " + f.getId()
	                                                + " Name: " + f.getName()
	                                                + " Price: Rs." + f.getPrice());
	                                    }
	                                }

	                                break;

	                            case 3:

	                                System.out.print("Enter Customer ID: ");
	                                int cid = sc.nextInt();

	                                Customer cust = customerService.getCustomer(cid);

	                                System.out.print("Enter Restaurant ID: ");
	                                int restid = sc.nextInt();

	                                Restaurant res = foodService.getRestaurant(restid);

	                                System.out.print("Enter Food ID: ");
	                                int foodid = sc.nextInt();

	                                System.out.print("Enter Quantity: ");
	                                int qty = sc.nextInt();

	                                for (FoodItem f : res.getMenu()) {

	                                    if (f.getId() == foodid) {

	                                        cust.getCart().addItem(f, qty);

	                                        System.out.println("Food added to cart!");
	                                    }
	                                }

	                                break;

	                            case 4:

	                                System.out.print("Enter Customer ID: ");
	                                int custId = sc.nextInt();

	                                Customer customer = customerService.getCustomer(custId);

	                                System.out.println(customer.getCart());

	                                break;

	                            case 5:

	                                System.out.print("Enter Customer ID: ");
	                                int customerId = sc.nextInt();

	                                Customer cus = customerService.getCustomer(customerId);

	                                Order order = new Order(
	                                        orderService.getOrders().size() + 1,
	                                        cus
	                                );

	                                orderService.placeOrder(order);

	                                System.out.println("Order placed successfully!");

	                                break;

	                            case 6:

	                                for (Order o : orderService.getOrders()) {

	                                    System.out.println(o);
	                                }

	                                break;

	                        }

	                    } while (customerChoice != 7);

	                    break;

	            }

	        } while (mainChoice != 3);

	        sc.close();
	    }
	

}
