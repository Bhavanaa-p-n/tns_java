package com.placement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.placement.entity.User;
import com.placement.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService service;

    @PostMapping("/add")
    public User addUser(@RequestBody User user){
        return service.addUser(user);
    }

    @GetMapping("/all")
    public List<User> getUsers(){
        return service.getUsers();
    }
}