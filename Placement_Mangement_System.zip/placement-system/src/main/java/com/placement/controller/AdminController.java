package com.placement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.placement.entity.Admin;
import com.placement.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService service;

    @PostMapping("/add")
    public Admin addAdmin(@RequestBody Admin admin){
        return service.addAdmin(admin);
    }

    @GetMapping("/all")
    public List<Admin> getAdmins(){
        return service.getAdmins();
    }
}