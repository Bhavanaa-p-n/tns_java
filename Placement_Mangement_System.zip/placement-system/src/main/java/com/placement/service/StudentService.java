package com.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.entity.Student;
import com.placement.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository repository;

    // CREATE
    public Student addStudent(Student student) {
        return repository.save(student);
    }

    // READ
    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    // UPDATE
    public Student updateStudent(int id, Student student) {
        student.setId(id);
        return repository.save(student);
    }

    // DELETE
    public void deleteStudent(int id) {
        repository.deleteById(id);
    }
}