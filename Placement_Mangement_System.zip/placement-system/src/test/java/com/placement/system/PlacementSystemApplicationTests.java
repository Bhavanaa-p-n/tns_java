package com.placement.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
