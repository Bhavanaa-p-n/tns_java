package com.placement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.placement.entity.Placement;
import com.placement.service.PlacementService;

@RestController
@RequestMapping("/placement")
public class PlacementController {

    @Autowired
    private PlacementService service;

    @PostMapping("/add")
    public Placement addPlacement(@RequestBody Placement placement){
        return service.addPlacement(placement);
    }

    @GetMapping("/all")
    public List<Placement> getPlacements(){
        return service.getPlacements();
    }
}