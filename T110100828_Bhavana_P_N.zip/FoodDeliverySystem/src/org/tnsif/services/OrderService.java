package org.tnsif.services;

import java.util.*;

import org.tnsif.entities.*;



public class OrderService {



	    private List<Order> orders=new ArrayList<>();
	    private List<DeliveryPerson> deliveryPersons=new ArrayList<>();

	    public void placeOrder(Order o){
	        orders.add(o);
	    }

	    public List<Order> getOrders(){
	        return orders;
	    }

	    public void addDeliveryPerson(DeliveryPerson dp){
	        deliveryPersons.add(dp);
	    }

	    public DeliveryPerson getDeliveryPerson(int id){
	        for(DeliveryPerson d:deliveryPersons)
	            if(d.getDeliveryPersonId()==id)
	                return d;
	        return null;
	    }

	    public void assignDeliveryPerson(int orderId,int deliveryId){
	        for(Order o:orders)
	            if(o.getOrderId()==orderId)
	                o.setDeliveryPerson(getDeliveryPerson(deliveryId));
	    }
	
}
