package org.tnsif.entities;

import java.util.*;


public class Order {



	    private int orderId;
	    private Customer customer;
	    private Map<FoodItem,Integer> items;
	    private String status="Pending";
	    private DeliveryPerson deliveryPerson;

	    public Order(int orderId, Customer customer) {
	        this.orderId = orderId;
	        this.customer = customer;
	        this.items = new HashMap<>(customer.getCart().getItems());
	    }

	    public int getOrderId() {
	        return orderId;
	    }

	    public void setDeliveryPerson(DeliveryPerson dp) {
	        deliveryPerson = dp;
	    }

	    public String toString() {
	        return "Order{orderId="+orderId+", customer="+customer+
	                ", items="+items+", status="+status+
	                ", deliveryPerson="+deliveryPerson+"}";
	    }
	
}
